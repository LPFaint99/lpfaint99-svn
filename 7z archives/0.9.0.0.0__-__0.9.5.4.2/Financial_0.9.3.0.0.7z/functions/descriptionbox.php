<?php function descriptionbox($description){
	echo "<input type=\"text\" name=\"description\" maxlength=\"10\" value=\""
		. $description . "\">\n";
	}
?>