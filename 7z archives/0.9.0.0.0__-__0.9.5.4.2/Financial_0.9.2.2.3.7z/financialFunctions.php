<?php
	include("finFunc.php");
	include("finFunc2.php");
	include("finFunc3.php");
	include("finFunc4.php");
?>