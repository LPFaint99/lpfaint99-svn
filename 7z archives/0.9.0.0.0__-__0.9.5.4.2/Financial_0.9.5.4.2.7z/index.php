<html>
<head><title>Financial 0.9.5.4.2</title><?php
	error_reporting(0);
	
/* 	<!--<link href="<?php echo$app; ?>support/styles.css" rel="stylesheet" type="text/css">
--> */
?><?php
	require_once("f-config.php");
	$page = $_GET['page'];
	$accounttype;
	$accounts;	$accounts2;	$accounts3;
	$connection = mysql_connect(HOSTNAME, USERNAME, PASSWORD)
		or die('Unable to connect !');
	mysql_select_db(DATABASENAME)
		or die('Unable to select database! DATABASENAME');
	setupAcc($accounttype,$accounts,$accounts2,$accounts3);
?></head>
<body>
<?php
	if($page > 0){pagelayout2($page,$accounttype,$accounts);}
	else{?><table width=98%><tr><TD><?
		billsDue($accounts,$page);
		totals($accounts,$accounts3,$accounttype);
	?>	</tr></td></table>
	<?	mainPage($page,$accounttype,$accounts,$accounts2,$accounts3);
		newTR(0,$accounts);
	}
	mysql_close($connection); 
?></body>
</html>


<?/*
	extract($_POST);extract($_SERVER);
	$host = "127.0.0.1";$local = true;$timeout = "1";
	if ($REMOTE_ADDR) {
		if ($REMOTE_ADDR != $host) {
			$local = false;
		}
	}
	if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS']))
		{$uri2 = 'https://';}
		else {$uri2 = 'http://';}
	$uri2 .= $_SERVER['HTTP_HOST'];
	$fti = 'ftp://' . $_SERVER['HTTP_HOST'];
	$uri = $uri2 . '/';
	$app = $uri . 'webapps/';
*/?>