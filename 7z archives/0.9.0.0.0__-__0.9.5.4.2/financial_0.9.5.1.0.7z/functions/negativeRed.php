<?php function negativeRed($num){
	if($num < 0){
		echo "<font color = red>";
	}
}
?>