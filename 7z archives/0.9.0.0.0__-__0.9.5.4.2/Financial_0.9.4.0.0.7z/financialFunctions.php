<?php
	include("functions/accountdropdown.php");
	include("functions/amountbox.php");
	include("functions/balanceRemaining.php");
	include("functions/currentAmount.php");
	include("functions/daydropdown.php");
	include("functions/descriptionbox.php");
	include("functions/edittrans.php");
	include("functions/isZero.php");
	include("functions/monthdropdown.php");
	include("functions/negativeRed.php");
	include("functions/newestTransaction.php");
	include("functions/pagelayout.php");
	include("functions/reloadPHP.php");
	include("functions/selected.php");
	include("functions/setupAcc.php");
	include("functions/submitTransaction.php");
	include("functions/sumMonth.php");
	include("functions/yeardropdown.php");
	include("functions/newTR.php");
?>


